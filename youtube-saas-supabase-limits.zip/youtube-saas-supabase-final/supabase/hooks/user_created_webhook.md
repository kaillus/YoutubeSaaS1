# Supabase Webhook 자동화 설정 (사용자 생성 시 프리미엄 설정)

1. Supabase → `Authentication > Add Webhook`
2. 이벤트: `auth.user_created`
3. 엔드포인트 URL:
   https://your-frontend-url.com/api/user/autoPremiumWithExpiry
4. HTTP Method: POST
5. 헤더:
   - Content-Type: application/json
6. 예시 페이로드:
{
  "email": "{{ user.email }}"
}
7. 사용 시 자동으로 프리미엄 유저 + 유효기간 등록 완료