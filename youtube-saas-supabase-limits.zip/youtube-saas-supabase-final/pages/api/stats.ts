import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(_: NextApiRequest, res: NextApiResponse) {
  const { count: userCount } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true });

  const { count: premiumCount } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })
    .eq('is_premium', true);

  return res.status(200).json({ users: userCount || 0, premiums: premiumCount || 0 });
}