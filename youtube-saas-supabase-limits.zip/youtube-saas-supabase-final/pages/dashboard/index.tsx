import { useEffect, useState } from "react";

export default function Dashboard() {
  const [stats, setStats] = useState({ users: 0, premiums: 0 });

  useEffect(() => {
    fetch("/api/stats")
      .then((res) => res.json())
      .then(setStats);
  }, []);

  return (
    <div style={{ padding: 40 }}>
      <h1>📊 통계 대시보드</h1>
      <p>전체 사용자 수: {stats.users}</p>
      <p>프리미엄 사용자 수: {stats.premiums}</p>
    </div>
  );
}